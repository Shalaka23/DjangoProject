from django import forms
from .models import PdfFile


class UserUploadForm(forms.ModelForm):
    class Meta:
        model = PdfFile
        fields = ('file_name', 'file',)