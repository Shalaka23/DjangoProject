from django.db import models
import uuid

# Create your models here.
class PdfFile(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    file_name = models.CharField(max_length=25)
    file = models.FileField(upload_to='uploads/')
    created = models.DateTimeField(auto_now_add=True)

    def __str__(self): return f'File name: {str(self.file_name)}'