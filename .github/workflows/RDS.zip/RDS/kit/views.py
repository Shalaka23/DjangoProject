from django.shortcuts import render
from django.contrib import messages

from .forms import UserUploadForm

# Create your views here.
def home_view(request):
    template_name='kit/home_page.html'
    user_upload_form = UserUploadForm(request.POST or None, request.FILES or None)

    if user_upload_form.is_valid() and 'file_name' in request.POST:
        uploaded_file = request.FILES['file']

        # check if its csv
        if not uploaded_file.name.endswith('.pdf'):
            messages.error(request, 'Uploaded file is not a pdf!')
        else:
            messages.success(request, 'Successfully Uploaded!')


    context = {
        'page_name':'Home',
        'user_upload_form':user_upload_form,
    }

    return render(request, template_name, context)